import Foundation

struct Reminder: Codable, Identifiable, Equatable {
    let id: UUID
    var title: String
    var fireDate: Date
    var isEnabled: Bool = true
    var weekdays: [Int] = []

    var repeatDescription: String {
        if weekdays.isEmpty { return "ครั้งเดียว" }
        if weekdays.count == 7 { return "ทุกวัน" }
        let names = [1: "อา.", 2: "จ.", 3: "อ.", 4: "พ.", 5: "พฤ.", 6: "ศ.", 7: "ส."]
        return weekdays.sorted().compactMap { names[$0] }.joined(separator: " ")
    }

    enum CodingKeys: String, CodingKey { case id, title, fireDate, isEnabled, weekdays }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(UUID.self, forKey: .id)
        title = try values.decode(String.self, forKey: .title)
        fireDate = try values.decode(Date.self, forKey: .fireDate)
        isEnabled = try values.decodeIfPresent(Bool.self, forKey: .isEnabled) ?? true
        weekdays = Array(Set(try values.decodeIfPresent([Int].self, forKey: .weekdays) ?? [])).filter { (1...7).contains($0) }.sorted()
    }

    init(id: UUID = UUID(), title: String, fireDate: Date) {
        self.id = id
        self.title = title
        self.fireDate = fireDate
    }
}
