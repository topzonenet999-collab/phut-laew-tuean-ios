import Foundation

struct Reminder: Codable, Identifiable, Equatable {
    let id: UUID
    var title: String
    var fireDate: Date

    init(id: UUID = UUID(), title: String, fireDate: Date) {
        self.id = id
        self.title = title
        self.fireDate = fireDate
    }
}
