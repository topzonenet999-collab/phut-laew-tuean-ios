import AlarmKit
import Combine
import Foundation
import SwiftUI

private struct ReminderMetadata: AlarmMetadata {}

@MainActor
final class ReminderStore: ObservableObject {
    @Published private(set) var reminders: [Reminder] = []
    @Published private(set) var scheduledIDs: Set<UUID> = []
    @Published var errorMessage: String?
    @Published var isSaving = false

    private let alarmManager = AlarmManager.shared
    private let fileURL: URL

    init() {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        fileURL = documents.appendingPathComponent("reminders.json")
        load()
        refreshAlarmState()
    }

    func refreshAlarmState() {
        alarmPermission = alarmManager.authorizationState == .authorized ? "อนุญาตแล้ว" : "ยังไม่ได้อนุญาต"
        do {
            scheduledIDs = Set(try alarmManager.alarms.map(\.id))
        } catch {
            errorMessage = "อ่านสถานะนาฬิกาปลุกไม่สำเร็จ: \(error.localizedDescription)"
        }
    }

    @Published private(set) var alarmPermission = "ยังไม่ได้ตรวจสิทธิ์"

    func requestAlarmPermission() async {
        do {
            let state = try await alarmManager.requestAuthorization()
            alarmPermission = state == .authorized ? "อนุญาตแล้ว" : "ยังไม่ได้อนุญาต"
            if state != .authorized { errorMessage = "กรุณาอนุญาตนาฬิกาปลุกในการตั้งค่า iPhone แล้วกลับมาลองใหม่" }
        } catch { errorMessage = "ขอสิทธิ์ไม่สำเร็จ: \(error.localizedDescription)" }
    }

    func add(title: String, fireDate: Date, weekdays: [Int] = []) async -> Bool {
        var reminder = Reminder(title: title, fireDate: fireDate)
        reminder.weekdays = weekdays
        return await save(reminder, replacing: nil)
    }

    func update(_ original: Reminder, title: String, fireDate: Date, weekdays: [Int], isEnabled: Bool) async -> Bool {
        var updated = Reminder(title: title, fireDate: fireDate)
        updated.weekdays = weekdays
        updated.isEnabled = isEnabled
        return await save(updated, replacing: original)
    }

    func setEnabled(_ original: Reminder, enabled: Bool) async {
        _ = await update(original, title: original.title, fireDate: original.fireDate,
                         weekdays: original.weekdays, isEnabled: enabled)
    }

    private func schedule(_ reminder: Reminder) async throws {
        let alert: AlarmPresentation.Alert
        if #available(iOS 26.1, *) {
            alert = AlarmPresentation.Alert(title: "\(reminder.title)")
        } else {
            alert = AlarmPresentation.Alert(title: "\(reminder.title)",
                stopButton: AlarmButton(text: "หยุด", textColor: .white, systemImageName: "stop.fill"))
        }
        let attributes = AlarmAttributes<ReminderMetadata>(presentation: AlarmPresentation(alert: alert),
            metadata: ReminderMetadata(), tintColor: .blue)
        let alarmSchedule: Alarm.Schedule
        if reminder.weekdays.isEmpty {
            alarmSchedule = .fixed(reminder.fireDate)
        } else {
            let days: [Int: Locale.Weekday] = [1: .sunday, 2: .monday, 3: .tuesday, 4: .wednesday,
                                              5: .thursday, 6: .friday, 7: .saturday]
            let components = Calendar.current.dateComponents([.hour, .minute], from: reminder.fireDate)
            alarmSchedule = .relative(.init(time: .init(hour: components.hour ?? 0, minute: components.minute ?? 0),
                repeats: .weekly(reminder.weekdays.compactMap { days[$0] })))
        }
        let configuration = AlarmManager.AlarmConfiguration<ReminderMetadata>.alarm(
            schedule: alarmSchedule, attributes: attributes, sound: .default)
        try await alarmManager.schedule(id: reminder.id, configuration: configuration)
    }

    private func save(_ draft: Reminder, replacing original: Reminder?) async -> Bool {
        guard !isSaving else { return false }
        var reminder = draft
        reminder.title = draft.title.trimmingCharacters(in: .whitespacesAndNewlines)
        reminder.weekdays = Array(Set(draft.weekdays)).filter { (1...7).contains($0) }.sorted()
        guard !reminder.title.isEmpty else { errorMessage = "กรุณาใส่ชื่อรายการ"; return false }
        guard !reminder.isEnabled || !reminder.weekdays.isEmpty || reminder.fireDate > Date().addingTimeInterval(5) else {
            errorMessage = "เวลาครั้งเดียวผ่านไปแล้ว กรุณาแก้เวลาแล้วเปิดปลุกใหม่"; return false
        }
        isSaving = true
        errorMessage = nil
        defer { isSaving = false }
        var created = false
        var cancelledOriginal = false
        do {
            if reminder.isEnabled {
                guard try await alarmManager.requestAuthorization() == .authorized else {
                    alarmPermission = "ยังไม่ได้อนุญาต"
                    errorMessage = "ยังตั้งปลุกไม่สำเร็จ กรุณาอนุญาตนาฬิกาปลุกในการตั้งค่า iPhone"; return false
                }
                alarmPermission = "อนุญาตแล้ว"
                guard !reminder.weekdays.isEmpty || reminder.fireDate > Date().addingTimeInterval(5) else {
                    errorMessage = "เวลาปลุกผ่านไประหว่างขอสิทธิ์ กรุณาเลือกเวลาใหม่"; return false
                }
                try await schedule(reminder)
                created = true
            }
            if let original, try alarmManager.alarms.contains(where: { $0.id == original.id }) {
                try alarmManager.cancel(id: original.id)
                cancelledOriginal = true
            }
            var updated = reminders.filter { $0.id != original?.id }
            updated.append(reminder)
            try persist(updated)
            reminders = updated.sorted { $0.fireDate < $1.fireDate }
            refreshAlarmState()
            return true
        } catch {
            if created { try? alarmManager.cancel(id: reminder.id) }
            if cancelledOriginal, let original {
                do { try await schedule(original) }
                catch { errorMessage = "บันทึกไม่สำเร็จ และคืนปลุกเดิมไม่ได้ กรุณาเปิดปลุกใหม่: \(error.localizedDescription)" }
            }
            refreshAlarmState()
            if errorMessage == nil { errorMessage = "ยังบันทึกการเปลี่ยนแปลงไม่สำเร็จ: \(error.localizedDescription)" }
            return false
        }
    }

    func remove(_ reminder: Reminder) {
        do {
            scheduledIDs = Set(try alarmManager.alarms.map(\.id))
            if scheduledIDs.contains(reminder.id) {
                try alarmManager.cancel(id: reminder.id)
            }
            let updated = reminders.filter { $0.id != reminder.id }
            try persist(updated)
            reminders = updated
            refreshAlarmState()
        } catch {
            refreshAlarmState()
            errorMessage = "ลบรายการไม่สำเร็จ: \(error.localizedDescription)"
        }
    }

    private func load() {
        guard FileManager.default.fileExists(atPath: fileURL.path) else { return }
        do {
            reminders = try JSONDecoder().decode([Reminder].self, from: Data(contentsOf: fileURL))
                .sorted { $0.fireDate < $1.fireDate }
        } catch {
            errorMessage = "อ่านรายการที่เก็บไว้ไม่สำเร็จ: \(error.localizedDescription)"
        }
    }

    private func persist(_ updated: [Reminder]) throws {
        let data = try JSONEncoder().encode(updated)
        try data.write(to: fileURL, options: .atomic)
    }
}
