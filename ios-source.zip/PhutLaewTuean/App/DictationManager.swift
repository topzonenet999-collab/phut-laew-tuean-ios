import AVFoundation
import Combine
import Foundation
import Speech

@MainActor
final class DictationManager: ObservableObject {
    @Published private(set) var transcript = ""
    @Published private(set) var isListening = false
    @Published private(set) var isStarting = false
    @Published var errorMessage: String?

    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "th-TH"))
    private var engine: AVAudioEngine?
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var committedText = ""
    private var sessionID = UUID()
    private var startID: UUID?
    private var startTask: Task<Void, Never>?

    func toggle() {
        if isListening || isStarting {
            stop()
            return
        }
        let newStartID = UUID()
        startID = newStartID
        isStarting = true
        startTask = Task { [weak self] in
            guard let self else { return }
            await self.start(id: newStartID)
        }
    }

    func stop() {
        startID = nil
        startTask?.cancel()
        startTask = nil
        isStarting = false
        isListening = false
        sessionID = UUID()
        finishCapture()
    }

    private func start(id: UUID) async {
        defer {
            if startID == id {
                startID = nil
                startTask = nil
                isStarting = false
            }
        }
        guard startID == id, !Task.isCancelled else { return }
        let speechAllowed = await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
        guard startID == id, !Task.isCancelled else { return }
        guard speechAllowed else {
            errorMessage = "กรุณาอนุญาตการรู้จำเสียงในการตั้งค่า iPhone"
            return
        }
        let microphoneAllowed = await AVAudioApplication.requestRecordPermission()
        guard startID == id, !Task.isCancelled else { return }
        guard microphoneAllowed else {
            errorMessage = "กรุณาอนุญาตไมโครโฟนในการตั้งค่า iPhone"
            return
        }
        guard recognizer?.isAvailable == true else {
            errorMessage = "บริการรู้จำเสียงภาษาไทยยังไม่พร้อม ลองเชื่อมต่ออินเทอร์เน็ตแล้วเปิดอีกครั้ง"
            return
        }

        committedText = ""
        transcript = ""
        isListening = true
        beginCapture()
    }

    private func beginCapture() {
        guard isListening, let recognizer else { return }
        do {
            sessionID = UUID()
            let currentSession = sessionID
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.record, mode: .measurement, options: .duckOthers)
            try session.setActive(true, options: .notifyOthersOnDeactivation)

            let engine = AVAudioEngine()
            let request = SFSpeechAudioBufferRecognitionRequest()
            request.shouldReportPartialResults = true
            let input = engine.inputNode
            let format = input.outputFormat(forBus: 0)
            input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
                request.append(buffer)
            }
            self.engine = engine
            self.request = request
            engine.prepare()
            try engine.start()
            task = recognizer.recognitionTask(with: request) { [weak self] result, error in
                let segment = result?.bestTranscription.formattedString
                let isFinal = result?.isFinal ?? false
                let recognitionError = error?.localizedDescription
                Task { @MainActor [weak self] in
                    guard let self, self.isListening, self.sessionID == currentSession else { return }
                    if let segment {
                        self.transcript = [self.committedText, segment]
                            .filter { !$0.isEmpty }.joined(separator: " ")
                    }
                    if isFinal {
                        self.committedText = self.transcript
                        self.finishCapture(deactivateSession: false)
                        self.beginCapture()
                    } else if let recognitionError {
                        self.errorMessage = "รับเสียงหยุดลง: \(recognitionError)"
                        self.stop()
                    }
                }
            }
        } catch {
            errorMessage = "เปิดไมโครโฟนไม่สำเร็จ: \(error.localizedDescription)"
            stop()
        }
    }

    private func finishCapture(deactivateSession: Bool = true) {
        engine?.stop()
        engine?.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        task?.cancel()
        task = nil
        request = nil
        engine = nil
        if deactivateSession {
            try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        }
    }
}
