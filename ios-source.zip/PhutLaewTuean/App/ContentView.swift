import SwiftUI
import AVFoundation
import Speech

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var store = ReminderStore()
    @StateObject private var dictation = DictationManager()
    @State private var title = ""
    @State private var fireDate = ContentView.defaultFireDate()
    @State private var parseWarning: String?
    @State private var savedMessage: String?
    @State private var weekdays: [Int] = []
    @State private var editing: Reminder?
    @State private var microphoneAllowed = false
    @State private var speechAllowed = false

    private static func defaultFireDate() -> Date {
        let oneHourLater = Date().addingTimeInterval(3600).timeIntervalSince1970
        return Date(timeIntervalSince1970: ceil(oneHourLater / 60) * 60)
    }

    private var visibleReminders: [Reminder] {
        store.reminders.sorted { $0.fireDate < $1.fireDate }
    }

    private var formattedFireDate: String {
        fireDate.formatted(.dateTime.weekday(.wide).day().month(.wide).year().hour().minute().locale(Locale(identifier: "th_TH")))
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    setupCard
                    entryCard
                    if let savedMessage {
                        Label(savedMessage, systemImage: "checkmark.circle.fill")
                            .font(.body.weight(.medium))
                            .foregroundStyle(.primary)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))
                            .accessibilityLabel(savedMessage)
                    }
                    reminderList
                    Text("รายการเก็บใน iPhone เครื่องนี้ การปลุกใช้ระบบของ iOS และทำงานหลังปิดแอป")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding()
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("พูดแล้วเตือน")
            .navigationBarTitleDisplayMode(.inline)
            .alert("แจ้งเตือน", isPresented: Binding(
                get: { store.errorMessage != nil || dictation.errorMessage != nil },
                set: { if !$0 { store.errorMessage = nil; dictation.errorMessage = nil } }
            )) {
                Button("ตกลง") { store.errorMessage = nil; dictation.errorMessage = nil }
            } message: {
                Text(store.errorMessage ?? dictation.errorMessage ?? "")
            }
            .sheet(item: $editing) { reminder in
                ReminderEditor(reminder: reminder, store: store)
            }
            .onAppear { refreshVoicePermissions() }
            .onChange(of: dictation.transcript) { _, newValue in
                guard !newValue.isEmpty else { return }
                let parsed = ThaiReminderParser.parse(newValue)
                title = parsed.title
                if let date = parsed.fireDate { fireDate = date }
                parseWarning = parsed.warning
                savedMessage = nil
            }
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active { store.refreshAlarmState(); refreshVoicePermissions() }
                if newPhase == .background { dictation.stop() }
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("มีอะไรต้องทำ")
                .font(.largeTitle.bold())
            Text("จดไว้ เดี๋ยวปลุกให้")
                .font(.title2.bold())
                .foregroundStyle(.blue)
            Text("เลือกเวลา แล้ว iPhone จะปลุกพร้อมชื่อรายการ แม้ปิดแอป")
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 12)
    }

    private func refreshVoicePermissions() {
        microphoneAllowed = AVAudioApplication.shared.recordPermission == .granted
        speechAllowed = SFSpeechRecognizer.authorizationStatus() == .authorized
    }

    private var setupCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("เริ่มใช้ใน 3 ขั้นตอน").font(.headline)
            Text("1. อนุญาตนาฬิกาปลุก เพื่อให้ระบบปลุกเมื่อปิดแอป")
            Label("นาฬิกาปลุก: \(store.alarmPermission)", systemImage: "alarm")
            Button("อนุญาตนาฬิกาปลุก") { Task { await store.requestAlarmPermission() } }
                .buttonStyle(.bordered).disabled(store.isSaving)
            Text("2. ถ้าต้องการเพิ่มด้วยเสียง ให้กด ‘พูด’ แล้วอนุญาตไมโครโฟนและการรู้จำเสียง พิมพ์เองได้โดยไม่ต้องใช้สิทธิ์นี้")
            Text("ไมโครโฟน: \(microphoneAllowed ? "อนุญาตแล้ว" : "ยังไม่ได้อนุญาต") • รู้จำเสียง: \(speechAllowed ? "อนุญาตแล้ว" : "ยังไม่ได้อนุญาต")")
                .font(.subheadline)
            Button("เปิดการตั้งค่าแอป") {
                if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
            }.buttonStyle(.bordered)
            Text("3. ทดลองปลุก แล้วล็อกหน้าจอ รอฟังเสียงและกดหยุด")
            Button("ทดลองปลุกในอีก 2 นาที") {
                Task {
                    if await store.add(title: "ทดลองปลุก", fireDate: Date().addingTimeInterval(120)) {
                        savedMessage = "ตั้งปลุกทดสอบแล้ว ล็อกหน้าจอและรออีก 2 นาที"
                    }
                }
            }.buttonStyle(.borderedProminent).disabled(store.isSaving)
            let missing = store.reminders.filter { $0.isEnabled && (!($0.weekdays.isEmpty) || $0.fireDate > Date()) && !store.scheduledIDs.contains($0.id) }
            if !missing.isEmpty {
                Label("มี \(missing.count) รายการที่ยังไม่มีปลุกในระบบ แตะแก้ไขแล้วบันทึกเพื่อลองใหม่", systemImage: "exclamationmark.triangle.fill")
                    .font(.body.weight(.semibold))
            }
        }
        .padding(20)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24))
    }

    private var entryCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("เพิ่มรายการใหม่")
                .font(.headline)
            HStack {
                TextField("เช่น ซื้ออาหารหมา", text: $title, axis: .vertical)
                    .font(.body)
                    .textInputAutocapitalization(.never)
                    .lineLimit(1...3)
                    .accessibilityLabel("ชื่อรายการ")
                Button {
                    dictation.toggle()
                } label: {
                    Label(dictation.isListening || dictation.isStarting ? "หยุด" : "พูด", systemImage: dictation.isListening || dictation.isStarting ? "stop.fill" : "mic.fill")
                }
                .buttonStyle(.bordered)
                .tint(dictation.isListening || dictation.isStarting ? .red : .blue)
                .disabled(dictation.isFinishing || store.isSaving)
                .accessibilityHint("กดพูดอีกครั้งเพื่อหยุดรับเสียง")
            }
            Text(dictation.isFinishing ? "กำลังเก็บคำท้ายประโยค…" : dictation.isStarting ? "กำลังเปิดไมโครโฟน กดหยุดเพื่อยกเลิก" : dictation.isListening ? "กำลังฟังอยู่ กดหยุดเมื่อพูดเสร็จ" : "ลองพูด “ซื้ออาหารหมา 6 โมงเช้า พรุ่งนี้”")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            if !dictation.transcript.isEmpty {
                VStack(alignment: .leading, spacing: 6) {
                    Text("ข้อความที่ได้ยินทั้งหมด").font(.subheadline.bold())
                    Text(dictation.transcript).font(.body).textSelection(.enabled)
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12))
            }
            if let parseWarning {
                Label(parseWarning, systemImage: "exclamationmark.triangle")
                    .font(.body.weight(.medium))
                    .foregroundStyle(.primary)
            }
            DatePicker("วันและเวลาปลุก", selection: Binding(
                get: { fireDate },
                set: { fireDate = $0; parseWarning = nil; savedMessage = nil }
            ), in: Date()..., displayedComponents: [.date, .hourAndMinute])
                .datePickerStyle(.compact)
                .environment(\.locale, Locale(identifier: "th_TH"))

            RepeatDayPicker(weekdays: $weekdays)

            Text("ตรวจสอบก่อนบันทึก: \(formattedFireDate)")
                .font(.body.weight(.medium))
                .foregroundStyle(.primary)
            Button("เตรียมทดสอบปลุกอีก 2 นาที") {
                weekdays = []
                title = "ทดสอบปลุก"
                fireDate = Date().addingTimeInterval(120)
                parseWarning = nil
                savedMessage = nil
            }
            .buttonStyle(.bordered)
            .disabled(dictation.isListening || dictation.isStarting || dictation.isFinishing || store.isSaving)

            Button {
                Task {
                    if await store.add(title: title, fireDate: fireDate, weekdays: weekdays) {
                        savedMessage = "ตั้งปลุกแล้ว: \(title) เวลา \(fireDate.formatted(date: .abbreviated, time: .shortened))"
                        weekdays = []
                        title = ""
                        fireDate = ContentView.defaultFireDate()
                        dictation.stop()
                    }
                }
            } label: {
                HStack {
                    Spacer()
                    if store.isSaving { ProgressView().tint(.white) }
                    Text(store.isSaving ? "กำลังตั้งปลุก" : "เพิ่มและตั้งปลุก")
                        .fontWeight(.semibold)
                    Spacer()
                }
                .padding(.vertical, 7)
            }
            .buttonStyle(.borderedProminent)
            .disabled(store.isSaving || dictation.isListening || dictation.isStarting || dictation.isFinishing || parseWarning != nil || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
        .padding(20)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24))
    }

    private var reminderList: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("รายการของคุณ")
                .font(.title3.bold())
            if visibleReminders.isEmpty {
                ContentUnavailableView("ยังไม่มีรายการ", systemImage: "alarm", description: Text("เพิ่มรายการด้านบนเพื่อตั้งปลุก"))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 25)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24))
            }
            ForEach(visibleReminders) { reminder in
                HStack(spacing: 14) {
                    Image(systemName: "alarm.fill")
                        .font(.title2)
                        .foregroundStyle(.blue)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(reminder.title).font(.headline)
                        Text(reminder.fireDate.formatted(.dateTime.day().month(.wide).year().hour().minute().locale(Locale(identifier: "th_TH"))))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text(reminder.repeatDescription).font(.subheadline)
                        Text(status(for: reminder))
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(.primary)
                    }
                    Spacer(minLength: 0)
                    VStack(spacing: 12) {
                        Toggle("เปิดปลุก", isOn: Binding(get: { reminder.isEnabled }, set: { enabled in
                            Task { await store.setEnabled(reminder, enabled: enabled) }
                        })).labelsHidden().disabled(store.isSaving)
                            .accessibilityLabel("เปิดปลุก \(reminder.title)")
                        Button("แก้ไข") { editing = reminder }.disabled(store.isSaving)
                    }
                    Button(role: .destructive) { store.remove(reminder) } label: {
                        Image(systemName: "trash")
                    }
                    .disabled(store.isSaving)
                    .accessibilityLabel("ลบ \(reminder.title)")
                }
                .padding(16)
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20))
            }
        }
    }

    private func status(for reminder: Reminder) -> String {
        if !reminder.isEnabled { return "ปิดปลุกอยู่" }
        if reminder.weekdays.isEmpty && reminder.fireDate <= Date() { return "ถึงเวลาแล้ว" }
        return store.scheduledIDs.contains(reminder.id) ? "ตั้งปลุกแล้ว" : "ยังไม่มีปลุกในระบบ แตะแก้ไขแล้วบันทึกใหม่"
    }
}


private struct RepeatDayPicker: View {
    @Binding var weekdays: [Int]
    private let days = [(2, "จ."), (3, "อ."), (4, "พ."), (5, "พฤ."), (6, "ศ."), (7, "ส."), (1, "อา.")]
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("ปลุกซ้ำ").font(.headline)
            HStack {
                Button("ครั้งเดียว") { weekdays = [] }
                Button("ทุกวัน") { weekdays = Array(1...7) }
            }.buttonStyle(.bordered)
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4)) {
                ForEach(days, id: \.0) { day in
                    Button {
                        if weekdays.contains(day.0) { weekdays.removeAll { $0 == day.0 } }
                        else { weekdays.append(day.0) }
                    } label: {
                        Label(day.1, systemImage: weekdays.contains(day.0) ? "checkmark.circle.fill" : "circle")
                            .frame(maxWidth: .infinity)
                    }.buttonStyle(.bordered)
                    .accessibilityLabel("\(day.1) \(weekdays.contains(day.0) ? "เลือกแล้ว" : "ยังไม่ได้เลือก")")
                }
            }
            Text(weekdays.isEmpty ? "ปลุกครั้งเดียวตามวันที่เลือก" : "ปลุกตามวันที่เลือกทุกสัปดาห์ ใช้เฉพาะเวลา วันที่ด้านบนไม่ใช้กับปลุกซ้ำ")
                .font(.subheadline).foregroundStyle(.secondary)
        }
    }
}

private struct ReminderEditor: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: ReminderStore
    let reminder: Reminder
    @State private var title: String
    @State private var fireDate: Date
    @State private var weekdays: [Int]
    @State private var isEnabled: Bool

    init(reminder: Reminder, store: ReminderStore) {
        self.reminder = reminder
        self.store = store
        _title = State(initialValue: reminder.title)
        _fireDate = State(initialValue: reminder.fireDate)
        _weekdays = State(initialValue: reminder.weekdays)
        _isEnabled = State(initialValue: reminder.isEnabled)
    }
    var body: some View {
        NavigationStack {
            Form {
                Section("รายการ") {
                    TextField("ชื่อรายการ", text: $title, axis: .vertical)
                    DatePicker("วันและเวลา", selection: $fireDate, displayedComponents: [.date, .hourAndMinute])
                        .environment(\.locale, Locale(identifier: "th_TH"))
                    Toggle("เปิดปลุก", isOn: $isEnabled)
                }
                Section { RepeatDayPicker(weekdays: $weekdays) }
                if let error = store.errorMessage {
                    Section { Label(error, systemImage: "exclamationmark.triangle.fill") }
                }
            }
            .navigationTitle("แก้ไขรายการ")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("ยกเลิก") { dismiss() }.disabled(store.isSaving)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(store.isSaving ? "กำลังบันทึก" : "บันทึก") {
                        Task {
                            if await store.update(reminder, title: title, fireDate: fireDate, weekdays: weekdays, isEnabled: isEnabled) { dismiss() }
                        }
                    }.disabled(store.isSaving || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .interactiveDismissDisabled(store.isSaving)
        }
    }
}
