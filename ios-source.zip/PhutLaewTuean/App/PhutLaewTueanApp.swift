import SwiftUI

@main
struct PhutLaewTueanApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
