import SwiftUI

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var store = ReminderStore()
    @StateObject private var dictation = DictationManager()
    @State private var title = ""
    @State private var fireDate = ContentView.defaultFireDate()
    @State private var parseWarning: String?
    @State private var savedMessage: String?

    private static func defaultFireDate() -> Date {
        let oneHourLater = Date().addingTimeInterval(3600).timeIntervalSince1970
        return Date(timeIntervalSince1970: ceil(oneHourLater / 60) * 60)
    }

    private var visibleReminders: [Reminder] {
        store.reminders.sorted { $0.fireDate < $1.fireDate }
    }

    private var formattedFireDate: String {
        fireDate.formatted(.dateTime.weekday(.wide).day().month(.wide).year().hour().minute().locale(Locale(identifier: "th_TH")))
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    entryCard
                    if let savedMessage {
                        Label(savedMessage, systemImage: "checkmark.circle.fill")
                            .font(.body.weight(.medium))
                            .foregroundStyle(.primary)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))
                            .accessibilityLabel(savedMessage)
                    }
                    reminderList
                    Text("รายการเก็บใน iPhone เครื่องนี้ การปลุกใช้ระบบของ iOS และทำงานหลังปิดแอป")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding()
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("พูดแล้วเตือน")
            .navigationBarTitleDisplayMode(.inline)
            .alert("แจ้งเตือน", isPresented: Binding(
                get: { store.errorMessage != nil || dictation.errorMessage != nil },
                set: { if !$0 { store.errorMessage = nil; dictation.errorMessage = nil } }
            )) {
                Button("ตกลง") { store.errorMessage = nil; dictation.errorMessage = nil }
            } message: {
                Text(store.errorMessage ?? dictation.errorMessage ?? "")
            }
            .onChange(of: dictation.transcript) { _, newValue in
                guard !newValue.isEmpty else { return }
                let parsed = ThaiReminderParser.parse(newValue)
                title = parsed.title
                if let date = parsed.fireDate { fireDate = date }
                parseWarning = parsed.warning
                savedMessage = nil
            }
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active { store.refreshAlarmState() }
                if newPhase == .background { dictation.stop() }
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("มีอะไรต้องทำ")
                .font(.largeTitle.bold())
            Text("จดไว้ เดี๋ยวปลุกให้")
                .font(.title2.bold())
                .foregroundStyle(.blue)
            Text("เลือกเวลา แล้ว iPhone จะปลุกพร้อมชื่อรายการ แม้ปิดแอป")
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 12)
    }

    private var entryCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("เพิ่มรายการใหม่")
                .font(.headline)
            HStack {
                TextField("เช่น ซื้ออาหารหมา", text: $title, axis: .vertical)
                    .font(.body)
                    .textInputAutocapitalization(.never)
                    .lineLimit(1...3)
                    .accessibilityLabel("ชื่อรายการ")
                Button {
                    dictation.toggle()
                } label: {
                    Label(dictation.isListening || dictation.isStarting ? "หยุด" : "พูด", systemImage: dictation.isListening || dictation.isStarting ? "stop.fill" : "mic.fill")
                }
                .buttonStyle(.bordered)
                .tint(dictation.isListening || dictation.isStarting ? .red : .blue)
                .disabled(dictation.isFinishing || store.isSaving)
                .accessibilityHint("กดพูดอีกครั้งเพื่อหยุดรับเสียง")
            }
            Text(dictation.isFinishing ? "กำลังเก็บคำท้ายประโยค…" : dictation.isStarting ? "กำลังเปิดไมโครโฟน กดหยุดเพื่อยกเลิก" : dictation.isListening ? "กำลังฟังอยู่ กดหยุดเมื่อพูดเสร็จ" : "ลองพูด “ซื้ออาหารหมา 6 โมงเช้า พรุ่งนี้”")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            if !dictation.transcript.isEmpty {
                VStack(alignment: .leading, spacing: 6) {
                    Text("ข้อความที่ได้ยินทั้งหมด").font(.subheadline.bold())
                    Text(dictation.transcript).font(.body).textSelection(.enabled)
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12))
            }
            if let parseWarning {
                Label(parseWarning, systemImage: "exclamationmark.triangle")
                    .font(.body.weight(.medium))
                    .foregroundStyle(.primary)
            }
            DatePicker("วันและเวลาปลุก", selection: Binding(
                get: { fireDate },
                set: { fireDate = $0; parseWarning = nil; savedMessage = nil }
            ), in: Date()..., displayedComponents: [.date, .hourAndMinute])
                .datePickerStyle(.compact)
                .environment(\.locale, Locale(identifier: "th_TH"))

            Text("ตรวจสอบก่อนบันทึก: \(formattedFireDate)")
                .font(.body.weight(.medium))
                .foregroundStyle(.primary)
            Button("เตรียมทดสอบปลุกอีก 2 นาที") {
                title = "ทดสอบปลุก"
                fireDate = Date().addingTimeInterval(120)
                parseWarning = nil
                savedMessage = nil
            }
            .buttonStyle(.bordered)
            .disabled(dictation.isListening || dictation.isStarting || dictation.isFinishing || store.isSaving)

            Button {
                Task {
                    if await store.add(title: title, fireDate: fireDate) {
                        savedMessage = "ตั้งปลุกแล้ว: \(title) เวลา \(fireDate.formatted(date: .abbreviated, time: .shortened))"
                        title = ""
                        fireDate = ContentView.defaultFireDate()
                        dictation.stop()
                    }
                }
            } label: {
                HStack {
                    Spacer()
                    if store.isSaving { ProgressView().tint(.white) }
                    Text(store.isSaving ? "กำลังตั้งปลุก" : "เพิ่มและตั้งปลุก")
                        .fontWeight(.semibold)
                    Spacer()
                }
                .padding(.vertical, 7)
            }
            .buttonStyle(.borderedProminent)
            .disabled(store.isSaving || dictation.isListening || dictation.isStarting || dictation.isFinishing || parseWarning != nil || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
        .padding(20)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24))
    }

    private var reminderList: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("รายการของคุณ")
                .font(.title3.bold())
            if visibleReminders.isEmpty {
                ContentUnavailableView("ยังไม่มีรายการ", systemImage: "alarm", description: Text("เพิ่มรายการด้านบนเพื่อตั้งปลุก"))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 25)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24))
            }
            ForEach(visibleReminders) { reminder in
                HStack(spacing: 14) {
                    Image(systemName: "alarm.fill")
                        .font(.title2)
                        .foregroundStyle(.blue)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(reminder.title).font(.headline)
                        Text(reminder.fireDate.formatted(.dateTime.day().month(.wide).year().hour().minute().locale(Locale(identifier: "th_TH"))))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text(status(for: reminder))
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(.primary)
                    }
                    Spacer(minLength: 0)
                    Button(role: .destructive) { store.remove(reminder) } label: {
                        Image(systemName: "trash")
                    }
                    .accessibilityLabel("ลบ \(reminder.title)")
                }
                .padding(16)
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20))
            }
        }
    }

    private func status(for reminder: Reminder) -> String {
        if reminder.fireDate <= Date() { return "ถึงเวลาแล้ว" }
        return store.scheduledIDs.contains(reminder.id) ? "ตั้งปลุกแล้ว" : "ปลุกในระบบหายไป กรุณาลบแล้วเพิ่มใหม่"
    }
}
