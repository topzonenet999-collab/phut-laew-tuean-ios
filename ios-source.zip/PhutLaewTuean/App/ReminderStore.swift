import AlarmKit
import Combine
import Foundation
import SwiftUI

private struct ReminderMetadata: AlarmMetadata {}

@MainActor
final class ReminderStore: ObservableObject {
    @Published private(set) var reminders: [Reminder] = []
    @Published private(set) var scheduledIDs: Set<UUID> = []
    @Published var errorMessage: String?
    @Published var isSaving = false

    private let alarmManager = AlarmManager.shared
    private let fileURL: URL

    init() {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        fileURL = documents.appendingPathComponent("reminders.json")
        load()
        refreshAlarmState()
    }

    func refreshAlarmState() {
        do {
            scheduledIDs = Set(try alarmManager.alarms.map(\.id))
        } catch {
            errorMessage = "อ่านสถานะนาฬิกาปลุกไม่สำเร็จ: \(error.localizedDescription)"
        }
    }

    func add(title: String, fireDate: Date) async -> Bool {
        guard !isSaving else { return false }
        let cleaned = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else {
            errorMessage = "กรุณาใส่ชื่อรายการ"
            return false
        }
        guard fireDate > Date().addingTimeInterval(5) else {
            errorMessage = "กรุณาเลือกเวลาในอนาคต"
            return false
        }

        isSaving = true
        defer { isSaving = false }
        do {
            guard try await alarmManager.requestAuthorization() == .authorized else {
                errorMessage = "ยังไม่ได้อนุญาตนาฬิกาปลุก กรุณาเปิดสิทธิ์ในการตั้งค่า iPhone"
                return false
            }
            guard fireDate > Date().addingTimeInterval(5) else {
                errorMessage = "เวลาปลุกผ่านไประหว่างขอสิทธิ์ กรุณาเลือกเวลาใหม่"
                return false
            }

            let reminder = Reminder(title: cleaned, fireDate: fireDate)
            let alert: AlarmPresentation.Alert
            if #available(iOS 26.1, *) {
                alert = AlarmPresentation.Alert(title: "\(cleaned)")
            } else {
                alert = AlarmPresentation.Alert(
                    title: "\(cleaned)",
                    stopButton: AlarmButton(text: "หยุด", textColor: .white, systemImageName: "stop.fill")
                )
            }
            let presentation = AlarmPresentation(alert: alert)
            let attributes = AlarmAttributes<ReminderMetadata>(
                presentation: presentation,
                metadata: ReminderMetadata(),
                tintColor: .blue
            )
            let configuration = AlarmManager.AlarmConfiguration<ReminderMetadata>.alarm(
                schedule: .fixed(fireDate),
                attributes: attributes,
                sound: .default
            )
            try await alarmManager.schedule(id: reminder.id, configuration: configuration)

            // Keep local data and the system alarm in sync if the file write fails.
            do {
                var updated = reminders
                updated.append(reminder)
                try persist(updated)
                reminders = updated.sorted { $0.fireDate < $1.fireDate }
                refreshAlarmState()
                return true
            } catch {
                try? alarmManager.cancel(id: reminder.id)
                throw error
            }
        } catch {
            errorMessage = "ตั้งปลุกไม่สำเร็จ: \(error.localizedDescription)"
            return false
        }
    }

    func remove(_ reminder: Reminder) {
        do {
            scheduledIDs = Set(try alarmManager.alarms.map(\.id))
            if scheduledIDs.contains(reminder.id) {
                try alarmManager.cancel(id: reminder.id)
            }
            let updated = reminders.filter { $0.id != reminder.id }
            try persist(updated)
            reminders = updated
            refreshAlarmState()
        } catch {
            refreshAlarmState()
            errorMessage = "ลบรายการไม่สำเร็จ: \(error.localizedDescription)"
        }
    }

    private func load() {
        guard FileManager.default.fileExists(atPath: fileURL.path) else { return }
        do {
            reminders = try JSONDecoder().decode([Reminder].self, from: Data(contentsOf: fileURL))
                .sorted { $0.fireDate < $1.fireDate }
        } catch {
            errorMessage = "อ่านรายการที่เก็บไว้ไม่สำเร็จ: \(error.localizedDescription)"
        }
    }

    private func persist(_ updated: [Reminder]) throws {
        let data = try JSONEncoder().encode(updated)
        try data.write(to: fileURL, options: .atomic)
    }
}
