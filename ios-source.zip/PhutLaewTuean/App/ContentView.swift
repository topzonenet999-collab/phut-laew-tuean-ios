import SwiftUI

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var store = ReminderStore()
    @StateObject private var dictation = DictationManager()
    @State private var title = ""
    @State private var fireDate = ContentView.defaultFireDate()

    private static func defaultFireDate() -> Date {
        let oneHourLater = Date().addingTimeInterval(3600).timeIntervalSince1970
        return Date(timeIntervalSince1970: ceil(oneHourLater / 60) * 60)
    }

    private var visibleReminders: [Reminder] {
        store.reminders.sorted { $0.fireDate < $1.fireDate }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    entryCard
                    reminderList
                    Text("รายการเก็บใน iPhone เครื่องนี้ การปลุกใช้ระบบของ iOS และทำงานหลังปิดแอป")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding()
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("พูดแล้วเตือน")
            .navigationBarTitleDisplayMode(.inline)
            .alert("แจ้งเตือน", isPresented: Binding(
                get: { store.errorMessage != nil || dictation.errorMessage != nil },
                set: { if !$0 { store.errorMessage = nil; dictation.errorMessage = nil } }
            )) {
                Button("ตกลง") { store.errorMessage = nil; dictation.errorMessage = nil }
            } message: {
                Text(store.errorMessage ?? dictation.errorMessage ?? "")
            }
            .onChange(of: dictation.transcript) { _, newValue in
                guard !newValue.isEmpty else { return }
                let parsed = ThaiReminderParser.parse(newValue)
                title = parsed.title
                if let date = parsed.fireDate { fireDate = date }
            }
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active { store.refreshAlarmState() }
                if newPhase == .background { dictation.stop() }
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("มีอะไรต้องทำ")
                .font(.largeTitle.bold())
            Text("จดไว้ เดี๋ยวปลุกให้")
                .font(.title2.bold())
                .foregroundStyle(.blue)
            Text("เลือกเวลา แล้ว iPhone จะปลุกพร้อมชื่อรายการ แม้ปิดแอป")
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 12)
    }

    private var entryCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("เพิ่มรายการใหม่")
                .font(.headline)
            HStack {
                TextField("เช่น ซื้ออาหารหมา", text: $title, axis: .vertical)
                    .textInputAutocapitalization(.never)
                    .lineLimit(1...3)
                    .accessibilityLabel("ชื่อรายการ")
                Button {
                    dictation.toggle()
                } label: {
                    Label(dictation.isListening || dictation.isStarting ? "หยุด" : "พูด", systemImage: dictation.isListening || dictation.isStarting ? "stop.fill" : "mic.fill")
                }
                .buttonStyle(.bordered)
                .tint(dictation.isListening || dictation.isStarting ? .red : .blue)
                .accessibilityHint("กดพูดอีกครั้งเพื่อหยุดรับเสียง")
            }
            Text(dictation.isStarting ? "กำลังเปิดไมโครโฟน กดหยุดเพื่อยกเลิก" : dictation.isListening ? "กำลังฟังอยู่ กดหยุดเมื่อพูดเสร็จ" : "ลองพูด “ซื้ออาหารหมา 6 โมงเช้า พรุ่งนี้”")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            DatePicker("วันและเวลาปลุก", selection: $fireDate, in: Date()..., displayedComponents: [.date, .hourAndMinute])
                .datePickerStyle(.compact)
                .environment(\.locale, Locale(identifier: "th_TH"))

            Button {
                Task {
                    if await store.add(title: title, fireDate: fireDate) {
                        title = ""
                        fireDate = ContentView.defaultFireDate()
                        dictation.stop()
                    }
                }
            } label: {
                HStack {
                    Spacer()
                    if store.isSaving { ProgressView().tint(.white) }
                    Text(store.isSaving ? "กำลังตั้งปลุก" : "เพิ่มและตั้งปลุก")
                        .fontWeight(.semibold)
                    Spacer()
                }
                .padding(.vertical, 7)
            }
            .buttonStyle(.borderedProminent)
            .disabled(store.isSaving || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
        .padding(20)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24))
    }

    private var reminderList: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("รายการของคุณ")
                .font(.title3.bold())
            if visibleReminders.isEmpty {
                ContentUnavailableView("ยังไม่มีรายการ", systemImage: "alarm", description: Text("เพิ่มรายการด้านบนเพื่อตั้งปลุก"))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 25)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24))
            }
            ForEach(visibleReminders) { reminder in
                HStack(spacing: 14) {
                    Image(systemName: "alarm.fill")
                        .font(.title2)
                        .foregroundStyle(.blue)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(reminder.title).font(.headline)
                        Text(reminder.fireDate.formatted(.dateTime.day().month(.wide).year().hour().minute().locale(Locale(identifier: "th_TH"))))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text(status(for: reminder))
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(.primary)
                    }
                    Spacer(minLength: 0)
                    Button(role: .destructive) { store.remove(reminder) } label: {
                        Image(systemName: "trash")
                    }
                    .accessibilityLabel("ลบ \(reminder.title)")
                }
                .padding(16)
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20))
            }
        }
    }

    private func status(for reminder: Reminder) -> String {
        if reminder.fireDate <= Date() { return "ถึงเวลาแล้ว" }
        return store.scheduledIDs.contains(reminder.id) ? "ตั้งปลุกแล้ว" : "ปลุกในระบบหายไป กรุณาลบแล้วเพิ่มใหม่"
    }
}
