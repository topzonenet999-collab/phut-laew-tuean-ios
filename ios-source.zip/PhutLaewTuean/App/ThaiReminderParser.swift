import Foundation

struct ParsedReminder {
    let title: String
    let fireDate: Date?
    let warning: String?
}

enum ThaiReminderParser {
    private static let words = ["หนึ่ง": 1, "สอง": 2, "สาม": 3, "สี่": 4, "ห้า": 5,
                                "หก": 6, "เจ็ด": 7, "แปด": 8, "เก้า": 9, "สิบ": 10,
                                "สิบเอ็ด": 11, "สิบสอง": 12]
    private static let number = #"(สิบสอง|สิบเอ็ด|สิบ|หนึ่ง|สอง|สาม|สี่|ห้า|หก|เจ็ด|แปด|เก้า|[0-9]{1,2})"#

    static func parse(_ input: String, now: Date = Date(), calendar: Calendar = .current) -> ParsedReminder {
        var text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        for (index, digit) in Array("๐๑๒๓๔๕๖๗๘๙").enumerated() {
            text = text.replacingOccurrences(of: String(digit), with: String(index))
        }
        var dayOffset: Int?
        for (word, offset) in [("มะรืนนี้", 2), ("มะรืน", 2), ("พรุ่งนี้", 1), ("วันนี้", 0)] {
            if text.contains(word) {
                if let existing = dayOffset, existing != offset {
                    return ParsedReminder(title: input, fireDate: nil, warning: "พบมากกว่าหนึ่งวัน กรุณาเลือกวันและเวลาปลุกเอง")
                }
                dayOffset = offset
            }
        }
        let suffix = #"\s*(ครึ่ง|(?:[0-5]?[0-9])\s*นาที)?"#
        let patterns: [(String, String)] = [
            (#"(?<![0-9])([0-9]{1,2})[:.]([0-9]{2})\s*(?:นาฬิกา|น\.)?\s*(เช้า|บ่าย|เย็น|ค่ำ)?(?![0-9])"#, "clock"),
            (#"ตี\s*"# + number + suffix, "dawn"),
            (#"บ่าย\s*(?:"# + number + #")?\s*โมง"# + suffix, "afternoon"),
            (number + #"\s*ทุ่ม"# + suffix, "night"),
            (#"เที่ยง\s*(คืน|วัน)?\s*(ครึ่ง)?"#, "noon"),
            (number + #"\s*(?:โมง|นาฬิกา|น\.)\s*((?:ตอน)?(?:เช้า|บ่าย|เย็น|ค่ำ))?"# + suffix, "hour")
        ]
        var selected: NSTextCheckingResult?
        var kind = ""
        for (pattern, candidateKind) in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern),
                  let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) else { continue }
            if selected == nil || match.range.location < selected!.range.location {
                selected = match
                kind = candidateKind
            }
        }
        guard let match = selected else {
            return ParsedReminder(title: input.trimmingCharacters(in: .whitespacesAndNewlines), fireDate: nil,
                                  warning: "ยังแยกเวลาไม่ได้ กรุณาเลือกวันและเวลาปลุกก่อนบันทึก")
        }
        let nsText = text as NSString
        func group(_ index: Int) -> String {
            guard index < match.numberOfRanges, match.range(at: index).location != NSNotFound else { return "" }
            return nsText.substring(with: match.range(at: index))
        }
        func value(_ text: String) -> Int? { Int(text) ?? words[text] }
        func minutes(_ text: String) -> Int {
            if text == "ครึ่ง" { return 30 }
            return Int(text.replacingOccurrences(of: "นาที", with: "").trimmingCharacters(in: .whitespaces)) ?? 0
        }
        var hour = value(group(1)) ?? 0
        var minute = 0
        var valid = true
        switch kind {
        case "clock":
            minute = Int(group(2)) ?? 0
            if ["บ่าย", "เย็น", "ค่ำ"].contains(group(3)), hour < 12 { hour += 12 }
        case "dawn":
            valid = (1...5).contains(hour)
            minute = minutes(group(2))
        case "afternoon":
            hour = group(1).isEmpty ? 1 : hour
            valid = (1...4).contains(hour)
            hour += 12
            minute = minutes(group(2))
        case "night":
            valid = (1...5).contains(hour)
            hour += 18
            minute = minutes(group(2))
        case "noon":
            hour = group(1) == "คืน" ? 0 : 12
            minute = group(2) == "ครึ่ง" ? 30 : 0
        default:
            let period = group(2)
            if (period.contains("บ่าย") || period.contains("เย็น") || period.contains("ค่ำ")), hour < 12 { hour += 12 }
            minute = minutes(group(3))
        }
        guard valid, (0...23).contains(hour), (0...59).contains(minute) else {
            return ParsedReminder(title: input, fireDate: nil, warning: "เวลาที่พูดไม่ถูกต้อง กรุณาเลือกวันและเวลาปลุกเอง")
        }
        let base = calendar.date(byAdding: .day, value: dayOffset ?? 0, to: now) ?? now
        var date = calendar.date(bySettingHour: hour, minute: minute, second: 0, of: base)
        if dayOffset == nil, let proposed = date, proposed <= now {
            date = calendar.date(byAdding: .day, value: 1, to: proposed)
        }
        if let range = Range(match.range, in: text) {
            let prefix = String(text[..<range.lowerBound])
            let cleanedPrefix = prefix.replacingOccurrences(of: #"(?:^|\s)เวลา\s*$"#, with: " ", options: .regularExpression)
            text = cleanedPrefix + " " + String(text[range.upperBound...])
        }
        for word in ["มะรืนนี้", "มะรืน", "พรุ่งนี้", "วันนี้"] { text = text.replacingOccurrences(of: word, with: " ") }
        text = text.replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression).trimmingCharacters(in: .whitespacesAndNewlines)
        let warning: String? = (date != nil && date! <= now) ? "เวลาที่พูดผ่านไปแล้ว กรุณาเลือกเวลาใหม่" : nil
        return ParsedReminder(title: text, fireDate: date, warning: warning)
    }
}
