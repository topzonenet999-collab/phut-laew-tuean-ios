import SwiftUI
import AVFoundation
import Speech

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var store = ReminderStore()
    @StateObject private var dictation = DictationManager()
    @State private var title = ""
    @State private var fireDate = ContentView.defaultFireDate()
    @State private var parseWarning: String?
    @State private var savedMessage: String?
    @State private var weekdays: [Int] = []
    @State private var editing: Reminder?
    @State private var microphoneAllowed = false
    @State private var speechAllowed = false

    private static func defaultFireDate() -> Date {
        let oneHourLater = Date().addingTimeInterval(3600).timeIntervalSince1970
        return Date(timeIntervalSince1970: ceil(oneHourLater / 60) * 60)
    }

    private var visibleReminders: [Reminder] {
        store.reminders.sorted { $0.fireDate < $1.fireDate }
    }

    private var formattedFireDate: String {
        fireDate.formatted(.dateTime.weekday(.wide).day().month(.wide).year().hour().minute().locale(Locale(identifier: "th_TH")))
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    entryCard
                    if let savedMessage {
                        Label(savedMessage, systemImage: "checkmark.circle.fill")
                            .font(.body.weight(.medium))
                            .foregroundStyle(.primary)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .modifier(ClayCard())
                            .accessibilityLabel(savedMessage)
                    }
                    reminderList
                    setupCard
                    Text("รายการเก็บใน iPhone เครื่องนี้ การปลุกใช้ระบบของ iOS และทำงานหลังปิดแอป")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding()
            }
            .background(PastelBackdrop())
            .tint(.indigo)
            .fontDesign(.rounded)
            .navigationTitle("พูดแล้วเตือน")
            .navigationBarTitleDisplayMode(.inline)
            .alert("แจ้งเตือน", isPresented: Binding(
                get: { store.errorMessage != nil || dictation.errorMessage != nil },
                set: { if !$0 { store.errorMessage = nil; dictation.errorMessage = nil } }
            )) {
                Button("ตกลง") { store.errorMessage = nil; dictation.errorMessage = nil }
            } message: {
                Text(store.errorMessage ?? dictation.errorMessage ?? "")
            }
            .sheet(item: $editing) { reminder in
                ReminderEditor(reminder: reminder, store: store)
            }
            .onAppear { refreshVoicePermissions() }
            .onChange(of: dictation.transcript) { _, newValue in
                guard !newValue.isEmpty else { return }
                let parsed = ThaiReminderParser.parse(newValue)
                title = parsed.title
                if let date = parsed.fireDate { fireDate = date }
                parseWarning = parsed.warning
                savedMessage = nil
            }
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active { store.refreshAlarmState(); refreshVoicePermissions() }
                if newPhase == .background { dictation.stop() }
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(spacing: 8) {
                Image(systemName: "sparkles").foregroundStyle(.indigo)
                Text("เพื่อนช่วยจำของคุณ").font(.subheadline.weight(.semibold))
            }
            ViewThatFits(in: .horizontal) {
                HStack(spacing: 12) { heroCopy; Spacer(minLength: 0); ClayClock() }
                VStack(alignment: .leading, spacing: 16) { ClayClock(); heroCopy }
            }
            HStack(spacing: 8) {
                Image(systemName: "heart.fill").foregroundStyle(.pink)
                Text("จดนิดเดียว เบาใจได้ทั้งวัน").font(.subheadline.weight(.medium))
            }
        }
        .padding(22)
        .modifier(ClayCard())
    }

    private var heroCopy: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("มีอะไรต้องทำ").font(.title.bold())
            Text("เดี๋ยวปลุกให้ ♡").font(.title2.bold()).foregroundStyle(.indigo)
            Text("บอกสิ่งที่ต้องทำ แล้วเลือกเวลาปลุก")
                .font(.body).foregroundStyle(.secondary)
        }
        .fixedSize(horizontal: false, vertical: true)
    }

    private func refreshVoicePermissions() {
        microphoneAllowed = AVAudioApplication.shared.recordPermission == .granted
        speechAllowed = SFSpeechRecognizer.authorizationStatus() == .authorized
    }

    private var setupCard: some View {
        DisclosureGroup {
            VStack(alignment: .leading, spacing: 12) {
            Text("1. อนุญาตนาฬิกาปลุก เพื่อให้ระบบปลุกเมื่อปิดแอป")
            Label("นาฬิกาปลุก: \(store.alarmPermission)", systemImage: "alarm")
            Button("อนุญาตนาฬิกาปลุก") { Task { await store.requestAlarmPermission() } }
                .buttonStyle(ClayButtonStyle()).disabled(store.isSaving)
            Text("2. ถ้าต้องการเพิ่มด้วยเสียง ให้กด ‘พูด’ แล้วอนุญาตไมโครโฟนและการรู้จำเสียง พิมพ์เองได้โดยไม่ต้องใช้สิทธิ์นี้")
            Text("ไมโครโฟน: \(microphoneAllowed ? "อนุญาตแล้ว" : "ยังไม่ได้อนุญาต") • รู้จำเสียง: \(speechAllowed ? "อนุญาตแล้ว" : "ยังไม่ได้อนุญาต")")
                .font(.subheadline)
            Button("เปิดการตั้งค่าแอป") {
                if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
            }.buttonStyle(ClayButtonStyle())
            Text("3. ทดลองปลุก แล้วล็อกหน้าจอ รอฟังเสียงและกดหยุด")
            Button("ทดลองปลุกในอีก 2 นาที") {
                Task {
                    if await store.add(title: "ทดลองปลุก", fireDate: Date().addingTimeInterval(120)) {
                        savedMessage = "ตั้งปลุกทดสอบแล้ว ล็อกหน้าจอและรออีก 2 นาที"
                    }
                }
            }.buttonStyle(ClayButtonStyle(prominent: true)).disabled(store.isSaving)
            let missing = store.reminders.filter { $0.isEnabled && (!($0.weekdays.isEmpty) || $0.fireDate > Date()) && !store.scheduledIDs.contains($0.id) }
            if !missing.isEmpty {
                Label("มี \(missing.count) รายการที่ยังไม่มีปลุกในระบบ แตะแก้ไขแล้วบันทึกเพื่อลองใหม่", systemImage: "exclamationmark.triangle.fill")
                    .font(.body.weight(.semibold))
            }
            }
        } label: {
            Label("เริ่มใช้ & ทดลองปลุก", systemImage: "wand.and.stars")
                .font(.headline)
        }
        .padding(20)
        .modifier(ClayCard())
    }

    private var entryCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Label("วันนี้อยากให้ช่วยจำอะไร?", systemImage: "square.and.pencil")
                .font(.headline)
            HStack {
                TextField("เช่น ซื้ออาหารหมา", text: $title, axis: .vertical)
                    .font(.body)
                    .textInputAutocapitalization(.never)
                    .lineLimit(1...3)
                    .accessibilityLabel("ชื่อรายการ")
                    .padding(14)
                    .background(Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
                Button {
                    dictation.toggle()
                } label: {
                    Label(dictation.isListening || dictation.isStarting ? "หยุด" : "พูด", systemImage: dictation.isListening || dictation.isStarting ? "stop.fill" : "mic.fill")
                }
                .buttonStyle(ClayButtonStyle())
                .tint(dictation.isListening || dictation.isStarting ? .red : .blue)
                .disabled(dictation.isFinishing || store.isSaving)
                .accessibilityHint("กดพูดอีกครั้งเพื่อหยุดรับเสียง")
            }
            Text(dictation.isFinishing ? "กำลังเก็บคำท้ายประโยค…" : dictation.isStarting ? "กำลังเปิดไมโครโฟน กดหยุดเพื่อยกเลิก" : dictation.isListening ? "กำลังฟังอยู่ กดหยุดเมื่อพูดเสร็จ" : "ลองพูด “ซื้ออาหารหมา 6 โมงเช้า พรุ่งนี้”")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            if !dictation.transcript.isEmpty {
                VStack(alignment: .leading, spacing: 6) {
                    Text("ข้อความที่ได้ยินทั้งหมด").font(.subheadline.bold())
                    Text(dictation.transcript).font(.body).textSelection(.enabled)
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12))
            }
            if let parseWarning {
                Label(parseWarning, systemImage: "exclamationmark.triangle")
                    .font(.body.weight(.medium))
                    .foregroundStyle(.primary)
            }
            DatePicker("วันและเวลาปลุก", selection: Binding(
                get: { fireDate },
                set: { fireDate = $0; parseWarning = nil; savedMessage = nil }
            ), in: Date()..., displayedComponents: [.date, .hourAndMinute])
                .datePickerStyle(.compact)
                .environment(\.locale, Locale(identifier: "th_TH"))

            RepeatDayPicker(weekdays: $weekdays)

            Text("ตรวจสอบก่อนบันทึก: \(formattedFireDate)")
                .font(.body.weight(.medium))
                .foregroundStyle(.primary)
            Button("เตรียมทดสอบปลุกอีก 2 นาที") {
                weekdays = []
                title = "ทดสอบปลุก"
                fireDate = Date().addingTimeInterval(120)
                parseWarning = nil
                savedMessage = nil
            }
            .buttonStyle(ClayButtonStyle())
            .disabled(dictation.isListening || dictation.isStarting || dictation.isFinishing || store.isSaving)

            Button {
                Task {
                    if await store.add(title: title, fireDate: fireDate, weekdays: weekdays) {
                        savedMessage = "ตั้งปลุกแล้ว: \(title) เวลา \(fireDate.formatted(date: .abbreviated, time: .shortened))"
                        weekdays = []
                        title = ""
                        fireDate = ContentView.defaultFireDate()
                        dictation.stop()
                    }
                }
            } label: {
                HStack {
                    Spacer()
                    if store.isSaving { ProgressView().tint(.white) }
                    Text(store.isSaving ? "กำลังตั้งปลุก" : "เพิ่มและตั้งปลุก")
                        .fontWeight(.semibold)
                    Spacer()
                }
                .padding(.vertical, 7)
            }
            .buttonStyle(ClayButtonStyle(prominent: true))
            .disabled(store.isSaving || dictation.isListening || dictation.isStarting || dictation.isFinishing || parseWarning != nil || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
        .padding(20)
        .modifier(ClayCard())
    }

    private var reminderList: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("กล่องความจำ", systemImage: "tray.full.fill")
                .font(.title3.bold())
            if visibleReminders.isEmpty {
                ContentUnavailableView("ยังไม่มีรายการ", systemImage: "alarm", description: Text("เพิ่มรายการด้านบนเพื่อตั้งปลุก"))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 25)
                    .modifier(ClayCard())
            }
            ForEach(visibleReminders) { reminder in
                HStack(spacing: 14) {
                    Image(systemName: reminder.isEnabled ? "alarm.fill" : "moon.fill")
                        .font(.title2)
                        .foregroundStyle(.indigo)
                        .padding(12)
                        .background(Color.indigo.opacity(0.12), in: RoundedRectangle(cornerRadius: 16))
                    VStack(alignment: .leading, spacing: 4) {
                        Text(reminder.title).font(.headline).fixedSize(horizontal: false, vertical: true)
                        Text(reminder.fireDate.formatted(.dateTime.day().month(.wide).year().hour().minute().locale(Locale(identifier: "th_TH"))))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text(reminder.repeatDescription).font(.subheadline)
                        Text(status(for: reminder))
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(.primary)
                    }
                    Spacer(minLength: 0)
                    VStack(spacing: 12) {
                        Toggle("เปิดปลุก", isOn: Binding(get: { reminder.isEnabled }, set: { enabled in
                            Task { await store.setEnabled(reminder, enabled: enabled) }
                        })).labelsHidden().disabled(store.isSaving)
                            .accessibilityLabel("เปิดปลุก \(reminder.title)")
                        Button("แก้ไข") { editing = reminder }.disabled(store.isSaving)
                    }
                    Button(role: .destructive) { store.remove(reminder) } label: {
                        Image(systemName: "trash")
                    }
                    .disabled(store.isSaving)
                    .accessibilityLabel("ลบ \(reminder.title)")
                }
                .padding(16)
                .modifier(ClayCard())
            }
        }
    }

    private func status(for reminder: Reminder) -> String {
        if !reminder.isEnabled { return "ปิดปลุกอยู่" }
        if reminder.weekdays.isEmpty && reminder.fireDate <= Date() { return "ถึงเวลาแล้ว" }
        return store.scheduledIDs.contains(reminder.id) ? "ตั้งปลุกแล้ว" : "ยังไม่มีปลุกในระบบ แตะแก้ไขแล้วบันทึกใหม่"
    }
}


private struct RepeatDayPicker: View {
    @Binding var weekdays: [Int]
    private let days = [(2, "จ."), (3, "อ."), (4, "พ."), (5, "พฤ."), (6, "ศ."), (7, "ส."), (1, "อา.")]
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("ปลุกซ้ำ").font(.headline)
            HStack {
                Button("ครั้งเดียว") { weekdays = [] }
                Button("ทุกวัน") { weekdays = Array(1...7) }
            }.buttonStyle(ClayButtonStyle())
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4)) {
                ForEach(days, id: \.0) { day in
                    Button {
                        if weekdays.contains(day.0) { weekdays.removeAll { $0 == day.0 } }
                        else { weekdays.append(day.0) }
                    } label: {
                        Label(day.1, systemImage: weekdays.contains(day.0) ? "checkmark.circle.fill" : "circle")
                            .frame(maxWidth: .infinity)
                    }.buttonStyle(ClayButtonStyle())
                    .accessibilityLabel("\(day.1) \(weekdays.contains(day.0) ? "เลือกแล้ว" : "ยังไม่ได้เลือก")")
                }
            }
            Text(weekdays.isEmpty ? "ปลุกครั้งเดียวตามวันที่เลือก" : "ปลุกตามวันที่เลือกทุกสัปดาห์ ใช้เฉพาะเวลา วันที่ด้านบนไม่ใช้กับปลุกซ้ำ")
                .font(.subheadline).foregroundStyle(.secondary)
        }
    }
}

private struct ReminderEditor: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: ReminderStore
    let reminder: Reminder
    @State private var title: String
    @State private var fireDate: Date
    @State private var weekdays: [Int]
    @State private var isEnabled: Bool

    init(reminder: Reminder, store: ReminderStore) {
        self.reminder = reminder
        self.store = store
        _title = State(initialValue: reminder.title)
        _fireDate = State(initialValue: reminder.fireDate)
        _weekdays = State(initialValue: reminder.weekdays)
        _isEnabled = State(initialValue: reminder.isEnabled)
    }
    var body: some View {
        NavigationStack {
            Form {
                Section("รายการ") {
                    TextField("ชื่อรายการ", text: $title, axis: .vertical)
                    DatePicker("วันและเวลา", selection: $fireDate, displayedComponents: [.date, .hourAndMinute])
                        .environment(\.locale, Locale(identifier: "th_TH"))
                    Toggle("เปิดปลุก", isOn: $isEnabled)
                }
                Section { RepeatDayPicker(weekdays: $weekdays) }
                if let error = store.errorMessage {
                    Section { Label(error, systemImage: "exclamationmark.triangle.fill") }
                }
            }
            .tint(.indigo)
            .fontDesign(.rounded)
            .navigationTitle("แก้ไขรายการ")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("ยกเลิก") { dismiss() }.disabled(store.isSaving)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(store.isSaving ? "กำลังบันทึก" : "บันทึก") {
                        Task {
                            if await store.update(reminder, title: title, fireDate: fireDate, weekdays: weekdays, isEnabled: isEnabled) { dismiss() }
                        }
                    }.disabled(store.isSaving || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .interactiveDismissDisabled(store.isSaving)
        }
    }
}


private struct PastelBackdrop: View {
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        LinearGradient(colors: scheme == .dark
            ? [Color(red: 0.12, green: 0.10, blue: 0.20), Color(red: 0.07, green: 0.12, blue: 0.18)]
            : [Color(red: 0.94, green: 0.91, blue: 1.0), Color(red: 1.0, green: 0.94, blue: 0.95), Color(red: 0.90, green: 0.97, blue: 0.96)],
            startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
    }
}

private struct ClayCard: ViewModifier {
    @Environment(\.colorScheme) private var scheme
    func body(content: Content) -> some View {
        content
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous)
                .strokeBorder(Color.white.opacity(scheme == .dark ? 0.10 : 0.85), lineWidth: 1.5)
                .allowsHitTesting(false))
            .shadow(color: Color.indigo.opacity(scheme == .dark ? 0.12 : 0.10), radius: 16, x: 0, y: 10)
    }
}

private struct ClayButtonStyle: ButtonStyle {
    var prominent = false
    @Environment(\.isEnabled) private var enabled
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.body.weight(.semibold))
            .foregroundStyle(prominent ? Color.white : Color.primary)
            .padding(.horizontal, 15).padding(.vertical, 12)
            .background {
                RoundedRectangle(cornerRadius: 18)
                    .fill(LinearGradient(colors: prominent
                        ? [Color(red: 0.40, green: 0.33, blue: 0.76), Color(red: 0.27, green: 0.20, blue: 0.60)]
                        : [Color(uiColor: .tertiarySystemGroupedBackground), Color.indigo.opacity(scheme == .dark ? 0.18 : 0.09)],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
            }
            .overlay(RoundedRectangle(cornerRadius: 18)
                .strokeBorder(Color.white.opacity(scheme == .dark ? 0.12 : 0.55), lineWidth: 1)
                .allowsHitTesting(false))
            .shadow(color: Color.indigo.opacity(configuration.isPressed ? 0 : 0.20), radius: 0, x: 0, y: configuration.isPressed ? 0 : 4)
            .offset(y: configuration.isPressed ? 3 : 0)
            .opacity(enabled ? 1 : 0.45)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

private struct ClayClock: View {
    var body: some View {
        ZStack {
            Ellipse().fill(Color.indigo.opacity(0.15)).frame(width: 90, height: 16).offset(y: 53).blur(radius: 4)
            Capsule().fill(Color(red: 0.52, green: 0.43, blue: 0.78)).frame(width: 15, height: 28).rotationEffect(.degrees(25)).offset(x: -26, y: 41)
            Capsule().fill(Color(red: 0.52, green: 0.43, blue: 0.78)).frame(width: 15, height: 28).rotationEffect(.degrees(-25)).offset(x: 26, y: 41)
            Ellipse().fill(.pink.gradient).frame(width: 38, height: 24).rotationEffect(.degrees(-30)).offset(x: -32, y: -37)
            Ellipse().fill(.pink.gradient).frame(width: 38, height: 24).rotationEffect(.degrees(30)).offset(x: 32, y: -37)
            Circle().fill(LinearGradient(colors: [Color(red: 0.84, green: 0.76, blue: 1), Color(red: 0.55, green: 0.44, blue: 0.81)], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 96, height: 96)
                .shadow(color: .indigo.opacity(0.25), radius: 5, x: 3, y: 6)
            Circle().fill(LinearGradient(colors: [.white, Color(red: 1, green: 0.93, blue: 0.90)], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 76, height: 76)
                .overlay(Circle().strokeBorder(.white.opacity(0.8), lineWidth: 3))
            RoundedRectangle(cornerRadius: 3).fill(Color.indigo).frame(width: 5, height: 22).offset(y: -10)
            RoundedRectangle(cornerRadius: 3).fill(Color.indigo).frame(width: 23, height: 5).rotationEffect(.degrees(25)).offset(x: 10, y: 3)
            Circle().fill(Color.indigo).frame(width: 9, height: 9)
            HStack(spacing: 28) {
                Circle().fill(Color.pink.opacity(0.45)).frame(width: 10, height: 6)
                Circle().fill(Color.pink.opacity(0.45)).frame(width: 10, height: 6)
            }.offset(y: 19)
            Image(systemName: "face.smiling").font(.system(size: 12, weight: .bold)).foregroundStyle(.indigo).offset(y: 23)
            Image(systemName: "sparkle").font(.system(size: 18, weight: .bold)).foregroundStyle(.orange).offset(x: 48, y: -48)
        }
        .frame(width: 120, height: 124)
        .accessibilityHidden(true)
    }
}
