# iOS cloud build status

Verified on 2026-10-03:

- Private repository: https://github.com/topzonenet999-collab/phut-laew-tuean-ios
- Successful run: https://github.com/topzonenet999-collab/phut-laew-tuean-ios/actions/runs/37124810403
- Workflow commit: `801d0ea330c5066b3c24203dcc2060097078b40b`
- Source archive commit: `8044e4174bee75382766cd89979f49ee443cfe2e`
- Runner: `macos-26`, Xcode 26.6 (17F113), simulator SDK 26.5.
- Build: Debug, generic iOS Simulator, `CODE_SIGNING_ALLOWED=NO`.
- Result: Success; total duration 28 seconds, job duration 19 seconds.

## Using Windows

The private repository contains `ios-source.zip`. Extract it to obtain the Xcode project and Swift source files. The root GitHub workflow extracts the same archive before compilation. To repeat the compiler check, open Actions → Build iOS app → Run workflow → main.

The first run used the private repository's shared free allowance. On 2026-10-03 the user rejected allowance-limited cloud builds. The current workflow now skips the entire hosted job while the repository is private, before runner allocation. It can run only in a public repository using the standard macOS runner. Repository visibility has not been changed; public disclosure requires the user's approval.

The workflow runs only when manually requested, uses read-only repository permissions, and has a 15 minute timeout. GitHub's documented free unlimited monthly build minutes apply to standard runners in public repositories; execution, concurrency and storage limits still apply. Creating another GitHub account is unnecessary and does not remove a private repository's limits.

## Still required before use or sale

This successful unsigned simulator compilation does not install the app on an iPhone, prove the actual alarm sound, or produce an App Store release.

For a free personal-device test, use a borrowed Mac with Xcode and an Apple Account to sign and install on the iPhone 11 running iOS 26 or later. Paid Apple Developer membership is a separate option for distribution, not configured here.

On the real phone, verify microphone/speech permission, AlarmKit permission, a two-minute alarm with the app closed and screen locked, the title displayed, the Stop control, and cancellation when deleting a future reminder. No personal-device test has been completed yet.
