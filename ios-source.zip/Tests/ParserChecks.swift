// Run concatenated with ThaiReminderParser.swift using Swift on the macOS build runner.
var calendar = Calendar(identifier: .gregorian)
calendar.timeZone = TimeZone(secondsFromGMT: 7 * 3600)!
let now = calendar.date(from: DateComponents(year: 2026, month: 10, day: 4, hour: 10))!
let cases: [(String, Int, Int, Int, String)] = [
    ("ซื้ออาหารหมา พรุ่งนี้ 6 โมงเช้า", 5, 6, 0, "ซื้ออาหารหมา"),
    ("ซื้ออาหารหมา หกโมงเช้า พรุ่งนี้", 5, 6, 0, "ซื้ออาหารหมา"),
    ("ซื้ออาหารหมา ๖:๓๐ พรุ่งนี้", 5, 6, 30, "ซื้ออาหารหมา"),
    ("โทรหาแม่ วันนี้ 14:15", 4, 14, 15, "โทรหาแม่"),
    ("โทรหาแม่ 6:00", 5, 6, 0, "โทรหาแม่"),
    ("ประชุม บ่ายโมง วันนี้", 4, 13, 0, "ประชุม"),
    ("ประชุม บ่ายสองโมงครึ่ง วันนี้", 4, 14, 30, "ประชุม"),
    ("ประชุม บ่าย 3 โมง 15 นาที วันนี้", 4, 15, 15, "ประชุม"),
    ("ซื้อขนม สองทุ่ม วันนี้", 4, 20, 0, "ซื้อขนม"),
    ("ซื้อขนม 3 ทุ่มครึ่ง วันนี้", 4, 21, 30, "ซื้อขนม"),
    ("ออกเดินทาง ตีห้า พรุ่งนี้", 5, 5, 0, "ออกเดินทาง"),
    ("ออกเดินทาง ตี 4 ครึ่ง พรุ่งนี้", 5, 4, 30, "ออกเดินทาง"),
    ("กินข้าว เที่ยง วันนี้", 4, 12, 0, "กินข้าว"),
    ("กินข้าว เที่ยงครึ่ง วันนี้", 4, 12, 30, "กินข้าว"),
    ("รับของ เที่ยงคืน พรุ่งนี้", 5, 0, 0, "รับของ"),
    ("รับของ สิบสองโมง วันนี้", 4, 12, 0, "รับของ"),
    ("รับของ สิบเอ็ดโมงเช้า มะรืนนี้", 6, 11, 0, "รับของ"),
    ("ซื้อขนม หกโมงเย็นวันนี้", 4, 18, 0, "ซื้อขนม"),
    ("บริหารเวลา 14:00 วันนี้", 4, 14, 0, "บริหารเวลา"),
    ("ซื้ออาหารหมา เวลา 6 โมงเช้า พรุ่งนี้ ให้หน่อย", 5, 6, 0, "ซื้ออาหารหมา ให้หน่อย")
]
for (input, day, hour, minute, title) in cases {
    let result = ThaiReminderParser.parse(input, now: now, calendar: calendar)
    guard let date = result.fireDate else { fatalError("Missing date: \(input)") }
    let components = calendar.dateComponents([.day, .hour, .minute, .second], from: date)
    precondition(components.day == day && components.hour == hour && components.minute == minute && components.second == 0, "Wrong time: \(input) -> \(date)")
    precondition(result.title == title, "Wrong title: \(input) -> \(result.title)")
    precondition(result.warning == nil, "Unexpected warning: \(input)")
}
for input in ["ซื้อขนม วันนี้ 6 โมงเช้า", "รับของ วันนี้ 25:00", "รับของ 12:99", "ออกเดินทาง ตีแปด พรุ่งนี้", "ประชุม วันนี้ พรุ่งนี้ 14:00", "โทรหาแม่ พรุ่งนี้"] {
    precondition(ThaiReminderParser.parse(input, now: now, calendar: calendar).warning != nil, "Expected manual review: \(input)")
}
print("Passed 26 Thai reminder parsing checks")

let legacyData = #"[{"id":"00000000-0000-0000-0000-000000000001","title":"รายการเดิม","fireDate":0}]"#.data(using: .utf8)!
let legacy = try JSONDecoder().decode([Reminder].self, from: legacyData)[0]
precondition(legacy.isEnabled && legacy.weekdays.isEmpty, "Old reminders must retain defaults")
var repeating = Reminder(title: "ทุกวัน", fireDate: now)
repeating.weekdays = Array(1...7)
repeating.isEnabled = false
let roundTrip = try JSONDecoder().decode(Reminder.self, from: JSONEncoder().encode(repeating))
precondition(roundTrip == repeating && roundTrip.repeatDescription == "ทุกวัน", "Repeat and enabled settings must persist")
print("Passed legacy reminder migration and repeat persistence checks")
