import Foundation

struct ParsedReminder {
    let title: String
    let fireDate: Date?
}

enum ThaiReminderParser {
    static func parse(_ input: String, now: Date = Date()) -> ParsedReminder {
        var text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        let calendar = Calendar.current
        var dayOffset: Int?
        if text.contains("มะรืน") {
            dayOffset = 2
            text = text.replacingOccurrences(of: "มะรืนนี้", with: " ").replacingOccurrences(of: "มะรืน", with: " ")
        } else if text.contains("พรุ่งนี้") {
            dayOffset = 1
            text = text.replacingOccurrences(of: "พรุ่งนี้", with: " ")
        } else if text.contains("วันนี้") {
            dayOffset = 0
            text = text.replacingOccurrences(of: "วันนี้", with: " ")
        }

        let words: [String: Int] = ["หนึ่ง": 1, "สอง": 2, "สาม": 3, "สี่": 4,
                                    "ห้า": 5, "หก": 6, "เจ็ด": 7, "แปด": 8,
                                    "เก้า": 9, "สิบ": 10, "สิบเอ็ด": 11]
        let numberPattern = #"(?<![\d:])([0-9]{1,2})(?:[:.]([0-5][0-9])\s*(?:นาฬิกา|น\.?)?|\s*(?:โมง|นาฬิกา|น\.))\s*((?:ตอน)?(?:เช้า|บ่าย|เย็น|ค่ำ))?\s*(ครึ่ง)?(?!\d)"#
        let wordPattern = #"(สิบเอ็ด|สิบ|หนึ่ง|สอง|สาม|สี่|ห้า|หก|เจ็ด|แปด|เก้า)\s*โมง\s*((?:ตอน)?(?:เช้า|บ่าย|เย็น|ค่ำ))?\s*(ครึ่ง)?"#

        var hour: Int?
        var minute = 0
        var period = ""
        var matchedRange: NSRange?
        let nsText = text as NSString
        if let match = firstMatch(numberPattern, in: text) {
            hour = Int(nsText.substring(with: match.range(at: 1)))
            if match.range(at: 2).location != NSNotFound {
                minute = Int(nsText.substring(with: match.range(at: 2))) ?? 0
            } else if match.range(at: 4).location != NSNotFound {
                minute = 30
            }
            if match.range(at: 3).location != NSNotFound {
                period = nsText.substring(with: match.range(at: 3))
            }
            matchedRange = match.range
        } else if let match = firstMatch(wordPattern, in: text) {
            hour = words[nsText.substring(with: match.range(at: 1))]
            if match.range(at: 2).location != NSNotFound {
                period = nsText.substring(with: match.range(at: 2))
            }
            minute = match.range(at: 3).location == NSNotFound ? 0 : 30
            matchedRange = match.range
        }

        var date: Date?
        if var hour, hour <= 23 {
            if (period.contains("บ่าย") || period.contains("เย็น") || period.contains("ค่ำ")) && hour < 12 {
                hour += 12
            } else if period.contains("เช้า") && hour == 12 {
                hour = 0
            }
            let base = calendar.date(byAdding: .day, value: dayOffset ?? 0, to: now) ?? now
            date = calendar.date(bySettingHour: hour, minute: minute, second: 0, of: base)
            if dayOffset == nil, let proposed = date, proposed <= now {
                date = calendar.date(byAdding: .day, value: 1, to: proposed)
            }
        }

        if let matchedRange, let range = Range(matchedRange, in: text) {
            text.removeSubrange(range)
        }
        text = text.replacingOccurrences(of: "เวลา", with: " ")
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return ParsedReminder(title: text, fireDate: date)
    }

    private static func firstMatch(_ pattern: String, in text: String) -> NSTextCheckingResult? {
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return nil }
        return regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text))
    }
}
